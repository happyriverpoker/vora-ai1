
import React, { useState } from 'react';
import { UserProfile, AlertSettings, AIModel, PersonaWeights } from './types';

interface TuningLandingProps {
  profile: UserProfile;
  settings: AlertSettings;
  onRunScan: (p: UserProfile, s: AlertSettings) => void;
  onBack?: () => void;
  onNavigateToHQ: () => void;
  canGoBack?: boolean;
}

const PREDEFINED_MARKETS = [
  'Crypto', 'Stocks', 'Commodities', 'Currencies', 
  'Real Estate (RWA)', 'AI & Tech', 'Precious Metals', 'Bonds/Macro'
];

interface SentinelDef {
  id: keyof PersonaWeights;
  name: string;
  icon: React.ReactNode;
  color: string;
  desc: string;
  role: string;
}

const SENTINELS: SentinelDef[] = [
  { 
    id: 'safe', 
    name: 'VORA SHIELD', 
    color: 'blue', 
    role: 'PRESERVATION CORE',
    desc: 'Ensures capital preservation by identifying deep support levels and mitigating downside volatility for portfolio survival.',
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
      </svg>
    )
  },
  { 
    id: 'riskTaker', 
    name: 'VORA SCOUT', 
    color: 'orange', 
    role: 'SPECULATION CORE',
    desc: 'Detects high-velocity momentum spikes and aggressive breakouts in frontier market sectors to capture untapped alpha.',
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
      </svg>
    )
  },
  { 
    id: 'ta', 
    name: 'VORA PRISM', 
    color: 'emerald', 
    role: 'EXECUTION CORE',
    desc: 'Maps technical confluences and liquidity gaps to pinpoint high-probability geometric entries and exit points.',
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
      </svg>
    )
  },
  { 
    id: 'fa', 
    name: 'VORA CORE', 
    color: 'purple', 
    role: 'CATALYST CORE',
    desc: 'Synthesizes macro trends and institutional flows to decode the fundamental drivers behind major market pivots.',
    icon: (
      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
      </svg>
    )
  },
];

const PRESETS = [
  { id: 'default', name: 'Equilibrium', weights: { safe: 1, riskTaker: 1, ta: 1, fa: 1 } },
  { id: 'ta-focused', name: 'Technical', weights: { safe: 0.5, riskTaker: 0.8, ta: 2, fa: 0.7 } },
  { id: 'fa-focused', name: 'Macro', weights: { safe: 1, riskTaker: 0.5, ta: 0.5, fa: 2 } },
  { id: 'high-alpha', name: 'Aggressive', weights: { safe: 0.2, riskTaker: 2, ta: 1, fa: 0.8 } },
];

const TuningLanding: React.FC<TuningLandingProps> = ({ profile, settings, onRunScan, onBack, onNavigateToHQ, canGoBack }) => {
  const [formData, setFormData] = useState<UserProfile>(profile);
  const [alertData, setAlertData] = useState<AlertSettings>(settings);

  const toggleMarket = (market: string) => {
    const current = formData.focusAreas;
    if (current.includes(market)) {
      setFormData({ ...formData, focusAreas: current.filter(a => a !== market) });
    } else {
      setFormData({ ...formData, focusAreas: [...current, market] });
    }
  };

  const updateWeight = (id: keyof PersonaWeights, val: number) => {
    setFormData({
      ...formData,
      personaWeights: {
        ...formData.personaWeights,
        [id]: val
      }
    });
  };

  const applyPreset = (presetId: string) => {
    const preset = PRESETS.find(p => p.id === presetId);
    if (preset) {
      setFormData({ ...formData, personaWeights: { ...preset.weights } });
    }
  };

  const setModel = (m: AIModel) => {
    setFormData({ ...formData, selectedModel: m });
  };

  return (
    <div className="max-w-7xl w-full mx-auto animate-in fade-in duration-700 pb-20 px-4 md:px-8 overflow-x-hidden">
      <header className="flex flex-col md:flex-row items-center justify-between pt-8 pb-12 gap-6 text-center md:text-left">
        <div className="flex flex-col">
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black tracking-tighter text-white uppercase italic leading-none">
            COUNCIL <span className="text-indigo-500">CALIBRATION</span>
          </h1>
          <p className="text-slate-500 font-black uppercase tracking-[0.2em] mt-3 text-[10px] sm:text-xs">
            Refining the multi-agent research lens for global focus areas
          </p>
        </div>
        {canGoBack && (
          <button 
            onClick={onBack}
            className="px-6 py-3 bg-slate-900 border border-slate-800 rounded-2xl text-slate-400 hover:text-white transition-all flex items-center gap-3 active:scale-95 shadow-xl whitespace-nowrap"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            <span className="text-[10px] font-black uppercase tracking-widest">Dashboard</span>
          </button>
        )}
      </header>

      <div className="flex flex-col gap-10 sm:gap-14">
        <section className="p-6 sm:p-10 lg:p-12 bg-slate-900 border border-slate-800 rounded-[2.5rem] sm:rounded-[3rem] shadow-2xl relative overflow-hidden group">
          <div className="flex justify-between items-start mb-8 sm:mb-10">
             <div className="text-left">
                <h2 className="text-xl sm:text-2xl lg:text-3xl font-black text-emerald-400 uppercase tracking-tight mb-1">01. Scour Focus</h2>
                <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest">Global Acquisition parameters</p>
             </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {PREDEFINED_MARKETS.map(market => {
              const isSelected = formData.focusAreas.includes(market);
              return (
                <button
                  key={market}
                  onClick={() => toggleMarket(market)}
                  className={`px-4 py-6 rounded-2xl border text-[11px] lg:text-xs font-black uppercase tracking-tighter transition-all flex items-center justify-center text-center leading-tight ${
                    isSelected 
                    ? 'bg-emerald-600 border-emerald-400 text-white shadow-xl scale-[1.02]' 
                    : 'bg-slate-950 border-slate-800 text-slate-500 hover:border-slate-700 hover:text-slate-200'
                  }`}
                >
                  {market}
                </button>
              );
            })}
          </div>
        </section>

        <section className="p-6 sm:p-10 lg:p-12 bg-slate-900 border border-slate-800 rounded-[2.5rem] sm:rounded-[3rem] shadow-2xl relative overflow-hidden">
          <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center mb-10 gap-8 relative z-10">
            <div className="text-left">
              <h2 className="text-xl sm:text-2xl lg:text-4xl font-black text-indigo-400 uppercase tracking-tight mb-1">02. Priority Mixer</h2>
              <p className="text-[10px] sm:text-xs text-slate-500 font-black uppercase tracking-widest">Adjust Deliberation Bias</p>
            </div>
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full xl:w-auto">
              <select 
                 onChange={(e) => applyPreset(e.target.value)}
                 className="bg-slate-950 border border-slate-800 text-indigo-400 text-[10px] font-black uppercase focus:outline-none cursor-pointer p-4 rounded-2xl"
               >
                 {PRESETS.map(p => <option key={p.id} value={p.id} className="bg-slate-900 text-white">{p.name}</option>)}
              </select>
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-8 relative z-10">
            {SENTINELS.map(sentinel => {
              const weight = formData.personaWeights[sentinel.id];
              const textClass = sentinel.color === 'blue' ? 'text-blue-400' : sentinel.color === 'orange' ? 'text-orange-400' : sentinel.color === 'emerald' ? 'text-emerald-400' : 'text-purple-400';
              const borderClass = sentinel.color === 'blue' ? 'border-blue-500/30' : sentinel.color === 'orange' ? 'border-orange-500/30' : sentinel.color === 'emerald' ? 'border-emerald-500/30' : 'border-purple-500/30';
              const accentClass = sentinel.color === 'blue' ? 'accent-blue-500' : sentinel.color === 'orange' ? 'accent-orange-500' : sentinel.color === 'emerald' ? 'accent-emerald-500' : 'accent-purple-500';

              return (
                <div key={sentinel.id} className={`p-6 sm:p-10 bg-slate-950/60 border border-white/5 rounded-[2rem] sm:rounded-[2.5rem] flex flex-col gap-6 sm:gap-10 transition-all text-left`}>
                  <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
                    <div className="flex items-center gap-5">
                      <div className={`p-4 sm:p-5 rounded-2xl bg-slate-900 border ${borderClass} ${textClass} shadow-xl`}>
                        {sentinel.icon}
                      </div>
                      <div>
                        <h3 className="text-lg sm:text-xl lg:text-2xl font-black text-white uppercase tracking-tighter mb-1">{sentinel.name}</h3>
                        <p className="text-[9px] sm:text-[10px] font-black text-slate-600 uppercase tracking-widest">{sentinel.role}</p>
                      </div>
                    </div>
                    <div className="text-right">
                        <span className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tighter">{Math.round(weight * 100)}%</span>
                    </div>
                  </div>
                  <p className="text-base sm:text-lg lg:text-2xl text-slate-300 font-medium leading-relaxed italic opacity-90 border-t border-white/5 pt-6">
                    "{sentinel.desc}"
                  </p>
                  <input 
                    type="range" min="0" max="2" step="0.1" 
                    value={weight} 
                    onChange={(e) => updateWeight(sentinel.id, parseFloat(e.target.value))}
                    className={`w-full h-2 sm:h-3 bg-slate-800 rounded-full appearance-none cursor-pointer ${accentClass}`} 
                  />
                </div>
              );
            })}
          </div>
        </section>

        <div className="pt-8 text-center">
          <button 
            onClick={() => onRunScan(formData, alertData)}
            className="w-full py-12 md:py-16 lg:py-20 bg-white text-slate-950 rounded-[2.5rem] sm:rounded-[3rem] font-black text-2xl sm:text-4xl lg:text-7xl uppercase tracking-tighter shadow-2xl hover:scale-[1.01] active:scale-95 transition-all flex flex-col sm:flex-row items-center justify-center gap-6 group relative overflow-hidden px-6"
          >
            <span className="relative z-10 leading-none">SUMMON THE COUNCIL</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default TuningLanding;
